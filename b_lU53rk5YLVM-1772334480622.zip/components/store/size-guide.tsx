"use client"

import { useEffect, useRef, useState } from "react"
import { Ruler } from "lucide-react"

const clothingSizes = [
  { size: "S", chest: "88-92", waist: "72-76", length: "68" },
  { size: "M", chest: "96-100", waist: "80-84", length: "70" },
  { size: "L", chest: "104-108", waist: "88-92", length: "72" },
  { size: "XL", chest: "112-116", waist: "96-100", length: "74" },
  { size: "XXL", chest: "120-124", waist: "104-108", length: "76" },
]

const shoeSizes = [
  { eu: "39", cm: "24.5" },
  { eu: "40", cm: "25.0" },
  { eu: "41", cm: "25.7" },
  { eu: "42", cm: "26.5" },
  { eu: "43", cm: "27.3" },
  { eu: "44", cm: "28.0" },
  { eu: "45", cm: "28.8" },
]

type Tab = "clothing" | "shoes"

export function SizeGuide() {
  const ref = useRef<HTMLDivElement>(null)
  const [activeTab, setActiveTab] = useState<Tab>("clothing")

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.05 }
    )
    const elements = ref.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={ref} className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div data-animate className="opacity-0 translate-y-6 duration-700 text-center mb-14">
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">
            {"الأحجام المتوفرة"}
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mt-3 text-balance">
            {"دليل المقاسات"}
          </h2>
          <div className="w-16 h-1 bg-accent rounded-full mx-auto mt-4" />
          <p className="mt-4 text-muted-foreground max-w-md mx-auto leading-relaxed">
            {"جميع المقاسات من S إلى XXL متوفرة - استعمل الدليل باش تلقى مقاسك"}
          </p>
        </div>

        <div data-animate className="opacity-0 translate-y-6 duration-700 delay-200">
          <div className="flex justify-center gap-2 mb-6">
            <button
              onClick={() => setActiveTab("clothing")}
              className={`px-6 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
                activeTab === "clothing"
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              <Ruler className="inline-block ml-2 h-4 w-4" />
              {"مقاسات الملابس"}
            </button>
            <button
              onClick={() => setActiveTab("shoes")}
              className={`px-6 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
                activeTab === "shoes"
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {"مقاسات الأحذية"}
            </button>
          </div>

          <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              {activeTab === "clothing" ? (
                <table className="w-full">
                  <thead>
                    <tr className="bg-primary text-primary-foreground">
                      <th className="py-4 px-6 text-right font-semibold text-sm">{"المقاس"}</th>
                      <th className="py-4 px-6 text-right font-semibold text-sm">{"الصدر (سم)"}</th>
                      <th className="py-4 px-6 text-right font-semibold text-sm">{"الخصر (سم)"}</th>
                      <th className="py-4 px-6 text-right font-semibold text-sm">{"الطول (سم)"}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clothingSizes.map((row, i) => (
                      <tr
                        key={row.size}
                        className={`border-b border-border last:border-0 transition-colors hover:bg-accent/5 ${
                          i % 2 === 0 ? "" : "bg-muted/30"
                        }`}
                      >
                        <td className="py-4 px-6 font-bold text-accent text-lg">{row.size}</td>
                        <td className="py-4 px-6 text-foreground">{row.chest}</td>
                        <td className="py-4 px-6 text-foreground">{row.waist}</td>
                        <td className="py-4 px-6 text-foreground">{row.length}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <table className="w-full">
                  <thead>
                    <tr className="bg-primary text-primary-foreground">
                      <th className="py-4 px-6 text-right font-semibold text-sm">{"المقاس الأوروبي (EU)"}</th>
                      <th className="py-4 px-6 text-right font-semibold text-sm">{"طول القدم (سم)"}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {shoeSizes.map((row, i) => (
                      <tr
                        key={row.eu}
                        className={`border-b border-border last:border-0 transition-colors hover:bg-accent/5 ${
                          i % 2 === 0 ? "" : "bg-muted/30"
                        }`}
                      >
                        <td className="py-4 px-6 font-bold text-accent text-lg">{row.eu}</td>
                        <td className="py-4 px-6 text-foreground">{row.cm}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-4">
            {"* المقاسات تقريبية. إذا كنت بين مقاسين، اختر المقاس الأكبر."}
          </p>
        </div>
      </div>
    </section>
  )
}
