"use client"

import { useState } from "react"
import Image from "next/image"
import { ShoppingBag, Heart, Star, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { addToCart } from "@/lib/cart-store"
import { useToast } from "@/components/store/toast-provider"
import type { Product } from "@/lib/products-data"

export function ProductCard({
  product,
  onQuickView,
}: {
  product: Product
  onQuickView: (p: Product) => void
}) {
  const [isLiked, setIsLiked] = useState(false)
  const [selectedSize, setSelectedSize] = useState<string | null>(null)
  const { showToast } = useToast()

  const handleAddToCart = () => {
    if (!selectedSize) {
      showToast("اختر المقاس أولا", "error")
      return
    }
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: selectedSize,
    })
    showToast(`تمت إضافة ${product.name} للسلة`)
  }

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0

  return (
    <div className="group bg-card rounded-2xl overflow-hidden border border-border hover:border-accent/40 transition-all duration-500 hover:shadow-xl hover:shadow-accent/5 hover:-translate-y-1">
      <div className="relative aspect-square overflow-hidden">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {product.isNew && (
          <span className="absolute top-3 right-3 bg-accent text-accent-foreground text-[10px] font-bold px-2.5 py-1 rounded-full shadow-sm">
            {"جديد"}
          </span>
        )}

        {discount > 0 && (
          <span className="absolute top-3 left-3 bg-destructive text-accent-foreground text-[10px] font-bold px-2.5 py-1 rounded-full shadow-sm">
            {`-${discount}%`}
          </span>
        )}

        <div className="absolute top-12 left-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-2 group-hover:translate-x-0">
          <button
            onClick={() => setIsLiked(!isLiked)}
            className="w-9 h-9 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-all shadow-sm"
            aria-label={isLiked ? "Remove from favorites" : "Add to favorites"}
          >
            <Heart
              className={`h-4 w-4 transition-colors ${
                isLiked ? "fill-destructive text-destructive" : "text-foreground"
              }`}
            />
          </button>
          <button
            onClick={() => onQuickView(product)}
            className="w-9 h-9 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-all shadow-sm"
            aria-label="Quick view"
          >
            <Eye className="h-4 w-4 text-foreground" />
          </button>
        </div>

        <div className="absolute bottom-0 right-0 left-0 p-3 bg-gradient-to-t from-primary/70 via-primary/30 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-3 group-hover:translate-y-0">
          <div className="flex gap-1.5 justify-center flex-wrap">
            {product.sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`text-[10px] font-bold min-w-[32px] h-7 px-1.5 rounded-lg transition-all ${
                  selectedSize === size
                    ? "bg-accent text-accent-foreground scale-110"
                    : "bg-card/90 text-foreground hover:bg-card"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-medium text-accent uppercase tracking-wider">
            {product.category}
          </span>
          <div className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-accent text-accent" />
            <span className="text-[10px] text-muted-foreground">{product.rating}</span>
          </div>
        </div>

        <h3
          className="font-semibold text-foreground leading-snug cursor-pointer hover:text-accent transition-colors"
          onClick={() => onQuickView(product)}
        >
          {product.name}
        </h3>

        <div className="flex items-center justify-between mt-3">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-foreground">
              {product.price.toLocaleString("ar-DZ")}
            </span>
            <span className="text-xs text-muted-foreground">{"د.ج"}</span>
            {product.oldPrice && (
              <span className="text-xs text-muted-foreground line-through">
                {product.oldPrice.toLocaleString("ar-DZ")}
              </span>
            )}
          </div>
          <Button
            size="icon"
            className="h-9 w-9 rounded-xl bg-primary hover:bg-accent text-primary-foreground hover:text-accent-foreground transition-all duration-300"
            onClick={handleAddToCart}
            aria-label="Add to cart"
          >
            <ShoppingBag className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
