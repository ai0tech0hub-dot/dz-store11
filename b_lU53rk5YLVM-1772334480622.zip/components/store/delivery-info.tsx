"use client"

import { useEffect, useRef } from "react"
import { Truck, Clock, CreditCard, MapPin, CheckCircle, Package, Headphones } from "lucide-react"

const features = [
  {
    icon: Truck,
    title: "توصيل لباب المنزل",
    desc: "نوصلك طلبك لحد باب دارك في ولاية الجلفة وكل الولايات الأخرى.",
    highlight: false,
  },
  {
    icon: CreditCard,
    title: "الدفع عند الاستلام",
    desc: "ما تدفع حتى تشوف وتجرب المنتج - بلا أي مخاطرة عليك.",
    highlight: true,
  },
  {
    icon: Clock,
    title: "توصيل سريع",
    desc: "طلبك يوصلك في أقل من 48 ساعة داخل الولاية و 3-5 أيام لبقية الولايات.",
    highlight: false,
  },
  {
    icon: MapPin,
    title: "حي الحدائق - الجلفة",
    desc: "زورنا في المحل مباشرة وشوف التشكيلة كاملة وجرب قبل ما تشري.",
    highlight: false,
  },
  {
    icon: CheckCircle,
    title: "جودة مضمونة",
    desc: "كل المنتجات أصلية ومضمونة 100%. إذا عندك أي مشكلة نبدلولك.",
    highlight: true,
  },
  {
    icon: Package,
    title: "تغليف أنيق",
    desc: "طلبك يوصلك في تغليف محترم وآمن يحمي المنتج من أي ضرر.",
    highlight: false,
  },
]

export function DeliveryInfo() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.05 }
    )
    const elements = ref.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <section id="delivery" ref={ref} className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div data-animate className="opacity-0 translate-y-6 duration-700 text-center mb-16">
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">
            {"لماذا تختارنا؟"}
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mt-3 text-balance">
            {"خدمات التوصيل والضمان"}
          </h2>
          <div className="w-16 h-1 bg-accent rounded-full mx-auto mt-4" />
          <p className="mt-4 text-muted-foreground max-w-lg mx-auto leading-relaxed">
            {"نضمنلك تجربة تسوق مريحة وآمنة من البداية للنهاية"}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              data-animate
              className={`opacity-0 translate-y-6 duration-700 rounded-2xl p-6 border transition-all duration-500 group hover:shadow-lg cursor-default ${
                feature.highlight
                  ? "bg-primary text-primary-foreground border-primary hover:shadow-primary/20"
                  : "bg-card text-foreground border-border hover:border-accent/30 hover:shadow-accent/5"
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div
                className={`w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-all duration-300 ${
                  feature.highlight
                    ? "bg-accent/20 group-hover:bg-accent/30"
                    : "bg-accent/10 group-hover:bg-accent/20"
                }`}
              >
                <feature.icon
                  className={`h-7 w-7 ${feature.highlight ? "text-accent" : "text-accent"}`}
                />
              </div>
              <h3 className="text-lg font-bold">{feature.title}</h3>
              <p
                className={`mt-2 leading-relaxed text-sm ${
                  feature.highlight ? "text-primary-foreground/70" : "text-muted-foreground"
                }`}
              >
                {feature.desc}
              </p>
            </div>
          ))}
        </div>

        <div
          data-animate
          className="opacity-0 translate-y-6 duration-700 delay-500 mt-12 bg-accent/10 rounded-2xl p-8 border border-accent/20 flex flex-col md:flex-row items-center justify-between gap-6"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-accent/20 flex items-center justify-center flex-shrink-0">
              <Headphones className="h-7 w-7 text-accent" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-foreground">{"عندك سؤال؟ اتصل بنا!"}</h3>
              <p className="text-sm text-muted-foreground">
                {"فريقنا جاهز للإجابة على كل أسئلتك ومساعدتك في اختيار المنتج المناسب."}
              </p>
            </div>
          </div>
          <a
            href="tel:+213000000000"
            className="flex-shrink-0 bg-accent text-accent-foreground px-8 py-3 rounded-xl font-semibold hover:bg-accent/90 transition-all shadow-lg shadow-accent/20 hover:shadow-xl hover:shadow-accent/30"
          >
            {"اتصل بنا الآن"}
          </a>
        </div>
      </div>
    </section>
  )
}
