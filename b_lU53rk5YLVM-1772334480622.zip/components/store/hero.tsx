"use client"

import { useEffect, useRef, useState } from "react"
import { ArrowLeft, Truck, CreditCard, Shield, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

function CountUp({ end, suffix = "" }: { end: number; suffix?: string }) {
  const [val, setVal] = useState(0)
  const ref = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0
          const step = end / 40
          const timer = setInterval(() => {
            start += step
            if (start >= end) {
              setVal(end)
              clearInterval(timer)
            } else {
              setVal(Math.floor(start))
            }
          }, 30)
          observer.disconnect()
        }
      },
      { threshold: 0.5 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [end])

  return (
    <span ref={ref}>
      {val.toLocaleString("ar-DZ")}
      {suffix}
    </span>
  )
}

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.1 }
    )
    const elements = containerRef.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <section
      id="hero"
      ref={containerRef}
      className="relative min-h-screen flex items-center overflow-hidden pt-24"
    >
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-bg.jpg"
          alt=""
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-primary/85" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 w-full">
        <div className="max-w-2xl">
          <div data-animate className="opacity-0 translate-y-6 duration-700">
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/15 text-primary-foreground text-sm font-medium mb-6 border border-accent/25 backdrop-blur-sm">
              <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              {"تشكيلة جديدة 2026"}
            </span>
          </div>

          <h1
            data-animate
            className="opacity-0 translate-y-6 duration-700 delay-150 text-4xl md:text-6xl lg:text-7xl font-bold text-primary-foreground leading-tight text-balance"
          >
            {"أناقتك"}
            <br />
            {"تبدأ "}
            <span className="text-accent relative">
              {"من هنا"}
              <svg className="absolute -bottom-2 right-0 w-full" viewBox="0 0 200 12" fill="none">
                <path d="M2 8 C50 2, 150 2, 198 8" stroke="currentColor" strokeWidth="3" strokeLinecap="round" className="text-accent" />
              </svg>
            </span>
          </h1>

          <p
            data-animate
            className="opacity-0 translate-y-6 duration-700 delay-300 mt-6 text-lg md:text-xl text-primary-foreground/80 max-w-lg leading-relaxed"
          >
            {"أحذية عصرية و ملابس أنيقة بأفضل الأسعار. توصيل مجاني لولاية الجلفة مع الدفع عند الاستلام."}
          </p>

          <div
            data-animate
            className="opacity-0 translate-y-6 duration-700 delay-500 mt-10 flex flex-wrap gap-4"
          >
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 text-base rounded-xl shadow-lg shadow-accent/20 hover:shadow-xl hover:shadow-accent/30 transition-all duration-300 hover:-translate-y-0.5"
              asChild
            >
              <a href="#products">
                {"تسوق الآن"}
                <ArrowLeft className="mr-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground/25 text-primary-foreground hover:bg-primary-foreground/10 px-8 text-base rounded-xl transition-all duration-300 hover:-translate-y-0.5"
              asChild
            >
              <a href="#contact">{"اطلب الآن"}</a>
            </Button>
          </div>

          <div
            data-animate
            className="opacity-0 translate-y-6 duration-700 delay-700 mt-12 flex flex-wrap gap-8"
          >
            {[
              { value: 500, suffix: "+", label: "عميل سعيد" },
              { value: 200, suffix: "+", label: "منتج متوفر" },
              { value: 48, suffix: "", label: "ولاية توصيل" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl md:text-3xl font-bold text-accent">
                  <CountUp end={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-xs text-primary-foreground/60 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div
          data-animate
          className="opacity-0 translate-y-6 duration-700 delay-[900ms] mt-16 grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          {[
            {
              icon: Truck,
              title: "توصيل للمنزل",
              desc: "توصيل سريع لكل الولايات",
            },
            {
              icon: CreditCard,
              title: "الدفع عند الاستلام",
              desc: "ادفع فقط عند وصول طلبك",
            },
            {
              icon: Shield,
              title: "ضمان الجودة",
              desc: "منتجات أصلية 100%",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="flex items-center gap-4 bg-primary-foreground/5 backdrop-blur-md rounded-xl p-4 border border-primary-foreground/10 hover:bg-primary-foreground/10 transition-all duration-300 group"
            >
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-accent/15 flex items-center justify-center group-hover:bg-accent/25 transition-colors duration-300">
                <item.icon className="h-6 w-6 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-primary-foreground text-sm">
                  {item.title}
                </h3>
                <p className="text-xs text-primary-foreground/60">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div
          data-animate
          className="opacity-0 translate-y-6 duration-700 delay-[1100ms] mt-8 flex items-center gap-3"
        >
          <div className="flex -space-x-2 space-x-reverse">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-full bg-accent/30 border-2 border-primary flex items-center justify-center text-[10px] font-bold text-primary-foreground"
              >
                {String.fromCharCode(64 + i)}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} className="h-3 w-3 fill-accent text-accent" />
            ))}
          </div>
          <span className="text-xs text-primary-foreground/60">
            {"4.8/5 من 500+ تقييم"}
          </span>
        </div>
      </div>
    </section>
  )
}
