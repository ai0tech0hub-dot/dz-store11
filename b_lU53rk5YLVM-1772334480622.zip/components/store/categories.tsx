"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"

const categories = [
  {
    name: "أحذية",
    image: "/images/cat-shoes.jpg",
    count: "24 منتج",
    desc: "رياضية و كلاسيكية",
  },
  {
    name: "ملابس خارجية",
    image: "/images/cat-outer.jpg",
    count: "18 منتج",
    desc: "جاكيتات، سراويل، هوديات",
  },
  {
    name: "ملابس داخلية",
    image: "/images/cat-inner.jpg",
    count: "32 منتج",
    desc: "تيشرتات، ملابس داخلية، جوارب",
  },
]

export function Categories() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.1 }
    )
    const elements = ref.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <section id="categories" ref={ref} className="py-24 px-6 max-w-7xl mx-auto">
      <div data-animate className="opacity-0 translate-y-6 duration-700 text-center mb-16">
        <span className="text-sm font-semibold text-accent uppercase tracking-widest">
          {"تصفح حسب النوع"}
        </span>
        <h2 className="text-3xl md:text-5xl font-bold text-foreground mt-3 text-balance">
          {"التصنيفات"}
        </h2>
        <div className="w-16 h-1 bg-accent rounded-full mx-auto mt-4" />
        <p className="mt-4 text-muted-foreground max-w-md mx-auto leading-relaxed">
          {"اختر من بين مجموعة متنوعة من الأحذية والملابس بأحدث الموديلات"}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((cat, i) => (
          <a
            key={cat.name}
            href="#products"
            data-animate
            className={`opacity-0 translate-y-6 duration-700 group relative rounded-2xl overflow-hidden cursor-pointer aspect-[4/5] block`}
            style={{ transitionDelay: `${i * 150}ms` }}
          >
            <Image
              src={cat.image}
              alt={cat.name}
              fill
              className="object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/95 via-primary/40 to-primary/10 group-hover:via-primary/50 transition-all duration-500" />

            <div className="absolute top-4 right-4">
              <span className="px-3 py-1 rounded-full bg-accent/20 backdrop-blur-sm text-primary-foreground text-xs font-medium border border-accent/20">
                {cat.count}
              </span>
            </div>

            <div className="absolute bottom-0 right-0 left-0 p-6">
              <p className="text-xs text-accent font-medium mb-1">{cat.desc}</p>
              <h3 className="text-2xl font-bold text-primary-foreground">{cat.name}</h3>
              <div className="mt-4 flex items-center gap-2 text-primary-foreground/80 text-sm font-medium opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                <span>{"تصفح المنتجات"}</span>
                <ArrowLeft className="h-4 w-4" />
              </div>
              <div className="mt-2 w-0 group-hover:w-16 transition-all duration-500 h-0.5 bg-accent rounded-full" />
            </div>
          </a>
        ))}
      </div>
    </section>
  )
}
