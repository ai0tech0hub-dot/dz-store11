import { MapPin, Phone, Mail, Facebook, Instagram } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <span className="text-3xl font-bold tracking-tight">STYLE DZ</span>
            <p className="mt-4 text-primary-foreground/70 leading-relaxed max-w-sm text-sm">
              {"متجر الأزياء و الأحذية في حي الحدائق، الجلفة. نوفرلك أحدث التشكيلات بأسعار منافسة مع خدمة توصيل ممتازة والدفع عند الاستلام."}
            </p>
            <div className="flex gap-3 mt-6">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-primary-foreground/10 flex items-center justify-center hover:bg-accent/20 hover:text-accent transition-all duration-300"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-primary-foreground/10 flex items-center justify-center hover:bg-accent/20 hover:text-accent transition-all duration-300"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-5 text-lg">{"روابط سريعة"}</h4>
            <ul className="flex flex-col gap-3 text-sm text-primary-foreground/70">
              {[
                { label: "الرئيسية", href: "#hero" },
                { label: "المنتجات", href: "#products" },
                { label: "التصنيفات", href: "#categories" },
                { label: "التوصيل", href: "#delivery" },
                { label: "اتصل بنا", href: "#contact" },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="hover:text-accent transition-colors duration-200 inline-flex items-center gap-1 group"
                  >
                    <span className="w-0 group-hover:w-2 h-0.5 bg-accent transition-all duration-200" />
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-5 text-lg">{"معلومات التواصل"}</h4>
            <ul className="flex flex-col gap-4 text-sm text-primary-foreground/70">
              <li>
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 hover:text-accent transition-colors"
                >
                  <MapPin className="h-4 w-4 text-accent flex-shrink-0" />
                  {"حي الحدائق، الجلفة"}
                </a>
              </li>
              <li>
                <a href="tel:+213000000000" className="flex items-center gap-3 hover:text-accent transition-colors">
                  <Phone className="h-4 w-4 text-accent flex-shrink-0" />
                  <span dir="ltr">+213 000 000 000</span>
                </a>
              </li>
              <li>
                <a href="mailto:contact@stylezdz.com" className="flex items-center gap-3 hover:text-accent transition-colors">
                  <Mail className="h-4 w-4 text-accent flex-shrink-0" />
                  {"contact@stylezdz.com"}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-primary-foreground/40">
            {`\u00A9 ${currentYear} STYLE DZ - `}{"جميع الحقوق محفوظة"}
          </p>
          <p className="text-sm text-primary-foreground/40">
            {"حي الحدائق، ولاية الجلفة، الجزائر"}
          </p>
        </div>
      </div>
    </footer>
  )
}
