"use client"

import Image from "next/image"
import { X, Minus, Plus, Trash2, ShoppingBag, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { removeFromCart, updateQuantity, clearCart } from "@/lib/cart-store"

export function CartSidebar({ onClose }: { onClose: () => void }) {
  const { cart, count, total } = useCart()

  const handleWhatsAppOrder = () => {
    const orderText = cart
      .map(
        (item) =>
          `- ${item.name} (مقاس: ${item.size}) x${item.quantity} = ${(item.price * item.quantity).toLocaleString("ar-DZ")} د.ج`
      )
      .join("\n")

    const message = encodeURIComponent(
      `مرحبا، أريد طلب المنتجات التالية:\n\n${orderText}\n\nالمجموع: ${total.toLocaleString("ar-DZ")} د.ج\n\nشكرا!`
    )
    window.open(`https://wa.me/213000000000?text=${message}`, "_blank")
  }

  return (
    <div className="fixed inset-0 z-[95] flex">
      <div
        className="absolute inset-0 bg-foreground/60 backdrop-blur-sm animate-in fade-in duration-200"
        onClick={onClose}
      />
      <div className="absolute top-0 right-0 bottom-0 w-full max-w-md bg-card shadow-2xl animate-in slide-in-from-right duration-300 flex flex-col border-l border-border">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-accent" />
            <h2 className="text-lg font-bold text-foreground">
              {"سلة المشتريات"}
            </h2>
            <span className="bg-accent text-accent-foreground text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
              {count}
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors"
            aria-label="Close cart"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center">
              <ShoppingBag className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">{"السلة فارغة"}</h3>
            <p className="text-muted-foreground text-sm">
              {"أضف بعض المنتجات وابدأ التسوق!"}
            </p>
            <Button onClick={onClose} className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl">
              {"تسوق الآن"}
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">
              {cart.map((item) => (
                <div
                  key={`${item.id}-${item.size}`}
                  className="flex gap-4 bg-background rounded-xl p-3 border border-border"
                >
                  <div className="relative w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-foreground text-sm truncate">
                      {item.name}
                    </h4>
                    <span className="text-xs text-muted-foreground">
                      {"مقاس: "}{item.size}
                    </span>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
                          className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-secondary text-foreground transition-colors"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="text-sm font-bold w-5 text-center text-foreground">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
                          className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-secondary text-foreground transition-colors"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <span className="font-bold text-sm text-foreground">
                        {(item.price * item.quantity).toLocaleString("ar-DZ")} {"د.ج"}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.id, item.size)}
                    className="self-start w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                    aria-label="Remove item"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="border-t border-border p-5 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">{"المجموع"}</span>
                <span className="text-2xl font-bold text-foreground">
                  {total.toLocaleString("ar-DZ")} {"د.ج"}
                </span>
              </div>
              <Button
                size="lg"
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl text-base"
                onClick={handleWhatsAppOrder}
              >
                <MessageCircle className="ml-2 h-5 w-5" />
                {"اطلب عبر واتساب"}
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 rounded-xl text-sm"
                  onClick={onClose}
                >
                  {"تابع التسوق"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-xl text-sm text-destructive hover:text-destructive"
                  onClick={clearCart}
                >
                  <Trash2 className="ml-1 h-3 w-3" />
                  {"تفريغ السلة"}
                </Button>
              </div>
              <p className="text-center text-xs text-muted-foreground">
                {"الدفع عند الاستلام - توصيل مجاني داخل الجلفة"}
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
