"use client"

import { useState, useEffect } from "react"
import { ShoppingBag, Menu, X, MapPin, Phone, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { CartSidebar } from "./cart-sidebar"

const navLinks = [
  { label: "الرئيسية", href: "#hero" },
  { label: "التصنيفات", href: "#categories" },
  { label: "المنتجات", href: "#products" },
  { label: "التوصيل", href: "#delivery" },
  { label: "اتصل بنا", href: "#contact" },
]

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [cartOpen, setCartOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const { count } = useCart()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
      setShowBackToTop(window.scrollY > 600)
    }
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      <header
        className={`fixed top-0 right-0 left-0 z-50 transition-all duration-500 ${
          scrolled
            ? "bg-card/95 backdrop-blur-xl shadow-lg shadow-foreground/5"
            : "bg-card/80 backdrop-blur-lg"
        } border-b border-border`}
      >
        <div className="flex items-center justify-between px-4 py-1.5 text-xs bg-primary text-primary-foreground">
          <div className="flex items-center gap-2">
            <MapPin className="h-3 w-3 flex-shrink-0" />
            <span>{"حي الحدائق، الجلفة - الجزائر"}</span>
          </div>
          <a href="tel:+213000000000" className="flex items-center gap-2 hover:text-accent transition-colors">
            <Phone className="h-3 w-3" />
            <span dir="ltr">+213 000 000 000</span>
          </a>
        </div>
        <nav className="flex items-center justify-between px-6 py-3 max-w-7xl mx-auto">
          <a href="#hero" className="flex items-center gap-2 group">
            <div className="flex flex-col items-start">
              <span className="text-2xl font-bold tracking-tight text-foreground group-hover:text-accent transition-colors duration-300">
                STYLE DZ
              </span>
              <span className="text-[10px] text-muted-foreground -mt-1">
                {"متجر الأزياء و الأحذية"}
              </span>
            </div>
          </a>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-accent transition-colors duration-200 relative after:absolute after:bottom-[-4px] after:right-0 after:w-0 after:h-[2px] after:bg-accent hover:after:w-full after:transition-all after:duration-300"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="relative hover:bg-accent/10"
              onClick={() => setCartOpen(true)}
              aria-label="Open cart"
            >
              <ShoppingBag className="h-5 w-5" />
              {count > 0 && (
                <span className="absolute -top-1 -left-1 bg-accent text-accent-foreground text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center animate-in zoom-in duration-200">
                  {count}
                </span>
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden hover:bg-accent/10"
              onClick={() => setIsOpen(!isOpen)}
              aria-label={isOpen ? "Close menu" : "Open menu"}
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </nav>

        {isOpen && (
          <div className="md:hidden bg-card border-t border-border animate-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col px-6 py-4 gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-sm font-medium text-muted-foreground hover:text-accent transition-colors py-3 px-4 rounded-xl hover:bg-accent/5"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        )}
      </header>

      {cartOpen && <CartSidebar onClose={() => setCartOpen(false)} />}

      {showBackToTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 w-12 h-12 bg-accent text-accent-foreground rounded-full shadow-lg flex items-center justify-center hover:bg-accent/90 transition-all animate-in fade-in zoom-in duration-300"
          aria-label="Back to top"
        >
          <ChevronUp className="h-5 w-5" />
        </button>
      )}
    </>
  )
}
