"use client"

import { useEffect, useRef } from "react"
import { Star, Quote } from "lucide-react"

const reviews = [
  {
    name: "محمد ب.",
    city: "الجلفة",
    rating: 5,
    text: "والله منتجات رائعة وتوصيل سريع. طلبت حذاء رياضي ووصلني في نفس اليوم. شكرا STYLE DZ!",
  },
  {
    name: "أحمد ك.",
    city: "المسيلة",
    rating: 5,
    text: "أحسن متجر في المنطقة. الجودة ممتازة والأسعار معقولة. نوصي بيهم بالعين المغمضة.",
  },
  {
    name: "ياسين م.",
    city: "الجلفة",
    rating: 4,
    text: "جاكيت شتوي شريته منهم، جودة عالية وراقي بزاف. التوصيل كان سريع والتغليف محترم.",
  },
  {
    name: "كريم ع.",
    city: "الأغواط",
    rating: 5,
    text: "ثاني مرة نشري منهم وديما راضي. المقاسات دقيقة والقماش ممتاز. ربي يبارك!",
  },
]

export function Reviews() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.05 }
    )
    const elements = ref.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={ref} className="py-24 px-6 bg-secondary/50">
      <div className="max-w-7xl mx-auto">
        <div data-animate className="opacity-0 translate-y-6 duration-700 text-center mb-16">
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">
            {"آراء العملاء"}
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mt-3 text-balance">
            {"ماذا يقول عملاؤنا؟"}
          </h2>
          <div className="w-16 h-1 bg-accent rounded-full mx-auto mt-4" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((review, i) => (
            <div
              key={review.name}
              data-animate
              className="opacity-0 translate-y-6 duration-700 bg-card rounded-2xl p-6 border border-border hover:border-accent/30 transition-all duration-300 hover:shadow-md group relative"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <Quote className="h-8 w-8 text-accent/20 absolute top-4 left-4" />
              <div className="flex items-center gap-1 mb-3">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star
                    key={j}
                    className={`h-4 w-4 ${
                      j < review.rating
                        ? "fill-accent text-accent"
                        : "text-border"
                    }`}
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                {`"${review.text}"`}
              </p>
              <div className="border-t border-border pt-3">
                <p className="font-semibold text-foreground text-sm">{review.name}</p>
                <p className="text-xs text-muted-foreground">{review.city}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
