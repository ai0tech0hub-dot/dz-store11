"use client"

import { useState } from "react"
import Image from "next/image"
import { X, ShoppingBag, Heart, Star, Truck, Shield, CreditCard, Minus, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { addToCart } from "@/lib/cart-store"
import { useToast } from "@/components/store/toast-provider"
import type { Product } from "@/lib/products-data"

export function ProductModal({
  product,
  onClose,
}: {
  product: Product
  onClose: () => void
}) {
  const [selectedSize, setSelectedSize] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [isLiked, setIsLiked] = useState(false)
  const { showToast } = useToast()

  const handleAddToCart = () => {
    if (!selectedSize) {
      showToast("اختر المقاس أولا", "error")
      return
    }
    for (let i = 0; i < quantity; i++) {
      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        size: selectedSize,
      })
    }
    showToast(`تمت إضافة ${product.name} للسلة`)
    onClose()
  }

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-foreground/60 backdrop-blur-sm animate-in fade-in duration-200"
        onClick={onClose}
      />
      <div className="relative bg-card rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-in zoom-in-95 fade-in duration-300 border border-border">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 z-10 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center hover:bg-background transition-colors"
          aria-label="Close"
        >
          <X className="h-5 w-5 text-foreground" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="relative aspect-square">
            <Image
              src={product.image}
              alt={product.name}
              fill
              className="object-cover rounded-t-2xl md:rounded-l-2xl md:rounded-tr-none"
            />
            {product.isNew && (
              <span className="absolute top-4 right-4 bg-accent text-accent-foreground text-xs font-bold px-3 py-1.5 rounded-full">
                {"جديد"}
              </span>
            )}
            {discount > 0 && (
              <span className="absolute top-4 right-20 bg-destructive text-accent-foreground text-xs font-bold px-3 py-1.5 rounded-full">
                {`-${discount}%`}
              </span>
            )}
          </div>

          <div className="p-6 md:p-8 flex flex-col">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < Math.floor(product.rating)
                        ? "fill-accent text-accent"
                        : "text-border"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">
                ({product.reviews} {"تقييم"})
              </span>
            </div>

            <span className="text-xs font-medium text-accent uppercase tracking-wider">
              {product.category}
            </span>
            <h2 className="text-2xl font-bold text-foreground mt-1">{product.name}</h2>
            <p className="text-muted-foreground text-sm mt-3 leading-relaxed">
              {product.description}
            </p>

            <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
              <span>{"الألوان:"}</span>
              <span className="font-medium text-foreground">{product.colors.join("، ")}</span>
            </div>

            <div className="flex items-baseline gap-3 mt-5">
              <span className="text-3xl font-bold text-foreground">
                {product.price.toLocaleString("ar-DZ")}
              </span>
              <span className="text-sm text-muted-foreground">{"د.ج"}</span>
              {product.oldPrice && (
                <span className="text-lg text-muted-foreground line-through">
                  {product.oldPrice.toLocaleString("ar-DZ")}
                </span>
              )}
            </div>

            <div className="mt-5">
              <span className="text-sm font-medium text-foreground mb-2 block">{"اختر المقاس:"}</span>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`min-w-[48px] h-10 px-3 rounded-xl text-sm font-semibold border transition-all duration-200 ${
                      selectedSize === size
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background text-foreground border-border hover:border-accent"
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <span className="text-sm font-medium text-foreground mb-2 block">{"الكمية:"}</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-xl border border-border flex items-center justify-center hover:bg-secondary transition-colors"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="text-lg font-bold w-8 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-xl border border-border flex items-center justify-center hover:bg-secondary transition-colors"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <Button
                size="lg"
                className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl text-base"
                onClick={handleAddToCart}
              >
                <ShoppingBag className="ml-2 h-5 w-5" />
                {"أضف للسلة"}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-xl"
                onClick={() => setIsLiked(!isLiked)}
              >
                <Heart
                  className={`h-5 w-5 ${isLiked ? "fill-destructive text-destructive" : ""}`}
                />
              </Button>
            </div>

            <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 text-accent" />
                <span>{"توصيل مجاني لولاية الجلفة"}</span>
              </div>
              <div className="flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-accent" />
                <span>{"الدفع عند الاستلام"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-accent" />
                <span>{"ضمان الجودة 100%"}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
