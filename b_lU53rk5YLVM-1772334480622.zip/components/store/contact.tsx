"use client"

import { useEffect, useRef, useState } from "react"
import { Send, MapPin, Phone, Clock, MessageCircle, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/store/toast-provider"

export function Contact() {
  const ref = useRef<HTMLDivElement>(null)
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    wilaya: "",
    order: "",
  })
  const { showToast } = useToast()

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.05 }
    )
    const elements = ref.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name.trim()) {
      showToast("الرجاء إدخال اسمك", "error")
      return
    }
    if (!formData.phone.trim()) {
      showToast("الرجاء إدخال رقم هاتفك", "error")
      return
    }
    if (!formData.order.trim()) {
      showToast("الرجاء كتابة تفاصيل طلبك", "error")
      return
    }

    const message = encodeURIComponent(
      `طلب جديد:\n\nالاسم: ${formData.name}\nالهاتف: ${formData.phone}\nالولاية: ${formData.wilaya}\n\nالطلب:\n${formData.order}`
    )
    window.open(`https://wa.me/213000000000?text=${message}`, "_blank")

    setSubmitted(true)
    setTimeout(() => {
      setSubmitted(false)
      setFormData({ name: "", phone: "", wilaya: "", order: "" })
    }, 4000)
  }

  const handleWhatsApp = () => {
    window.open(
      "https://wa.me/213000000000?text=" +
        encodeURIComponent("مرحبا، أريد الاستفسار عن منتجاتكم."),
      "_blank"
    )
  }

  return (
    <section id="contact" ref={ref} className="py-24 px-6 bg-secondary/30">
      <div className="max-w-7xl mx-auto">
        <div data-animate className="opacity-0 translate-y-6 duration-700 text-center mb-16">
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">
            {"تواصل معنا"}
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mt-3 text-balance">
            {"اطلب الآن"}
          </h2>
          <div className="w-16 h-1 bg-accent rounded-full mx-auto mt-4" />
          <p className="mt-4 text-muted-foreground max-w-md mx-auto leading-relaxed">
            {"ابعثلنا طلبك أو اتصل بنا مباشرة وراح نرد عليك في أقرب وقت"}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div data-animate className="opacity-0 translate-y-6 duration-700 delay-150">
            <div className="bg-card rounded-2xl border border-border p-8 shadow-sm">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-16 text-center animate-in fade-in zoom-in-95 duration-500">
                  <div className="w-20 h-20 rounded-full bg-accent/15 flex items-center justify-center mb-6">
                    <CheckCircle2 className="h-10 w-10 text-accent" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {"تم إرسال طلبك!"}
                  </h3>
                  <p className="text-muted-foreground max-w-sm">
                    {"شكرا لك! سنتواصل معك عبر الهاتف في أقرب وقت ممكن لتأكيد طلبك."}
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    {"نموذج الطلب السريع"}
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        {"الاسم الكامل"} <span className="text-destructive">*</span>
                      </label>
                      <Input
                        placeholder="الاسم..."
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                        className="rounded-xl bg-background"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        {"رقم الهاتف"} <span className="text-destructive">*</span>
                      </label>
                      <Input
                        placeholder="0000 000 0"
                        dir="ltr"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="rounded-xl bg-background text-left"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      {"الولاية والبلدية"}
                    </label>
                    <Input
                      placeholder="مثال: الجلفة - حي الحدائق"
                      value={formData.wilaya}
                      onChange={(e) =>
                        setFormData({ ...formData, wilaya: e.target.value })
                      }
                      className="rounded-xl bg-background"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">
                      {"تفاصيل طلبك"} <span className="text-destructive">*</span>
                    </label>
                    <Textarea
                      placeholder="اكتب تفاصيل طلبك هنا... (المنتج، المقاس، اللون، الكمية...)"
                      rows={4}
                      value={formData.order}
                      onChange={(e) =>
                        setFormData({ ...formData, order: e.target.value })
                      }
                      className="rounded-xl bg-background resize-none"
                    />
                  </div>
                  <Button
                    type="submit"
                    size="lg"
                    className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl shadow-lg shadow-accent/20 transition-all hover:shadow-xl hover:shadow-accent/30"
                  >
                    <Send className="ml-2 h-4 w-4" />
                    {"إرسال الطلب عبر واتساب"}
                  </Button>
                </form>
              )}
            </div>
          </div>

          <div data-animate className="opacity-0 translate-y-6 duration-700 delay-300 flex flex-col gap-5">
            {[
              {
                icon: MapPin,
                title: "العنوان",
                lines: ["حي الحدائق، الجلفة", "الجزائر"],
                action: null,
              },
              {
                icon: Phone,
                title: "الهاتف",
                lines: ["+213 000 000 000", "+213 111 111 111"],
                action: "tel:+213000000000",
              },
              {
                icon: Clock,
                title: "أوقات العمل",
                lines: ["السبت - الخميس: 09:00 - 21:00", "الجمعة: مغلق"],
                action: null,
              },
            ].map((info) => {
              const Wrapper = info.action ? "a" : "div"
              return (
                <Wrapper
                  key={info.title}
                  {...(info.action ? { href: info.action } : {})}
                  className="bg-card rounded-2xl border border-border p-6 flex items-start gap-4 hover:border-accent/30 transition-all duration-300 hover:shadow-md group"
                >
                  <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0 group-hover:bg-accent/20 transition-colors">
                    <info.icon className="h-6 w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">{info.title}</h3>
                    {info.lines.map((line, idx) => (
                      <p key={idx} className="text-muted-foreground text-sm mt-1">
                        {line}
                      </p>
                    ))}
                  </div>
                </Wrapper>
              )
            })}

            <div className="bg-primary rounded-2xl p-8 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent" />
              <div className="relative">
                <div className="w-16 h-16 rounded-full bg-accent/15 flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-8 w-8 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-primary-foreground mb-2">
                  {"اطلب عبر واتساب"}
                </h3>
                <p className="text-primary-foreground/70 text-sm mb-5 max-w-sm mx-auto">
                  {"ابعثلنا رسالة مباشرة على واتساب وراح نرد عليك فورا ونساعدك في اختيار المنتج المناسب"}
                </p>
                <Button
                  size="lg"
                  className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl shadow-lg shadow-accent/20"
                  onClick={handleWhatsApp}
                >
                  <MessageCircle className="ml-2 h-5 w-5" />
                  {"تواصل عبر واتساب"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
