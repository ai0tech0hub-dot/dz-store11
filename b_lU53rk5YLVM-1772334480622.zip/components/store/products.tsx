"use client"

import { useState, useEffect, useRef } from "react"
import { ProductCard } from "./product-card"
import { ProductModal } from "./product-modal"
import { Button } from "@/components/ui/button"
import { products, filterOptions, type Product } from "@/lib/products-data"
import { Search } from "lucide-react"

export function Products() {
  const [activeFilter, setActiveFilter] = useState("الكل")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const ref = useRef<HTMLDivElement>(null)

  const filteredProducts = products.filter((p) => {
    const matchesFilter =
      activeFilter === "الكل" ||
      (activeFilter === "أحذية" && p.category.includes("أحذية")) ||
      (activeFilter === "ملابس خارجية" && p.category === "ملابس خارجية") ||
      (activeFilter === "ملابس داخلية" && p.category === "ملابس داخلية")

    const matchesSearch =
      !searchQuery ||
      p.name.includes(searchQuery) ||
      p.category.includes(searchQuery) ||
      p.description.includes(searchQuery)

    return matchesFilter && matchesSearch
  })

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in", "fade-in", "slide-in-from-bottom-6")
            entry.target.classList.remove("opacity-0", "translate-y-6")
          }
        })
      },
      { threshold: 0.05 }
    )
    const elements = ref.current?.querySelectorAll("[data-animate]")
    elements?.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [activeFilter, searchQuery])

  return (
    <>
      <section id="products" ref={ref} className="py-24 px-6 bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <div data-animate className="opacity-0 translate-y-6 duration-700 text-center mb-10">
            <span className="text-sm font-semibold text-accent uppercase tracking-widest">
              {"تسوق الآن"}
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mt-3 text-balance">
              {"منتجاتنا المميزة"}
            </h2>
            <div className="w-16 h-1 bg-accent rounded-full mx-auto mt-4" />
            <p className="mt-4 text-muted-foreground max-w-md mx-auto leading-relaxed">
              {"أحدث التشكيلات بأسعار تنافسية - جميع الأحجام متوفرة"}
            </p>
          </div>

          <div
            data-animate
            className="opacity-0 translate-y-6 duration-700 delay-150 mb-10"
          >
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <div className="relative w-full sm:w-72">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="ابحث عن منتج..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-4 pr-10 py-2.5 rounded-xl border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent transition-all placeholder:text-muted-foreground"
                />
              </div>
              <div className="flex gap-2 flex-wrap justify-center">
                {filterOptions.map((option) => (
                  <Button
                    key={option}
                    variant={activeFilter === option ? "default" : "outline"}
                    size="sm"
                    onClick={() => setActiveFilter(option)}
                    className={`rounded-full px-5 transition-all duration-300 ${
                      activeFilter === option
                        ? "bg-accent text-accent-foreground shadow-md shadow-accent/20"
                        : "border-border text-muted-foreground hover:text-foreground hover:border-accent/40"
                    }`}
                  >
                    {option}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-2xl font-bold text-muted-foreground mb-2">
                {"لا توجد نتائج"}
              </p>
              <p className="text-muted-foreground">{"جرب البحث بكلمات أخرى"}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product, i) => (
                <div
                  key={product.id}
                  data-animate
                  className="opacity-0 translate-y-6 duration-700"
                  style={{ transitionDelay: `${200 + i * 80}ms` }}
                >
                  <ProductCard
                    product={product}
                    onQuickView={setSelectedProduct}
                  />
                </div>
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <p className="text-sm text-muted-foreground">
              {"عرض "}{filteredProducts.length}{" من "}{products.length}{" منتج"}
            </p>
          </div>
        </div>
      </section>

      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </>
  )
}
