export interface CartItem {
  id: number
  name: string
  price: number
  image: string
  size: string
  quantity: number
}

type Listener = () => void

let cart: CartItem[] = []
const listeners: Set<Listener> = new Set()

function notify() {
  listeners.forEach((l) => l())
}

export function getCart(): CartItem[] {
  return cart
}

export function getCartCount(): number {
  return cart.reduce((acc, item) => acc + item.quantity, 0)
}

export function getCartTotal(): number {
  return cart.reduce((acc, item) => acc + item.price * item.quantity, 0)
}

export function addToCart(item: Omit<CartItem, "quantity">) {
  const existing = cart.find((c) => c.id === item.id && c.size === item.size)
  if (existing) {
    existing.quantity += 1
  } else {
    cart = [...cart, { ...item, quantity: 1 }]
  }
  notify()
}

export function removeFromCart(id: number, size: string) {
  cart = cart.filter((c) => !(c.id === id && c.size === size))
  notify()
}

export function updateQuantity(id: number, size: string, quantity: number) {
  if (quantity <= 0) {
    removeFromCart(id, size)
    return
  }
  cart = cart.map((c) =>
    c.id === id && c.size === size ? { ...c, quantity } : c
  )
  notify()
}

export function clearCart() {
  cart = []
  notify()
}

export function subscribe(listener: Listener) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}
