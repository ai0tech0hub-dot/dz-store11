import { Navbar } from "@/components/store/navbar"
import { Hero } from "@/components/store/hero"
import { Categories } from "@/components/store/categories"
import { Products } from "@/components/store/products"
import { DeliveryInfo } from "@/components/store/delivery-info"
import { Reviews } from "@/components/store/reviews"
import { SizeGuide } from "@/components/store/size-guide"
import { Contact } from "@/components/store/contact"
import { Footer } from "@/components/store/footer"
import { ToastProvider } from "@/components/store/toast-provider"

export default function Home() {
  return (
    <ToastProvider>
      <main className="min-h-screen bg-background">
        <Navbar />
        <Hero />
        <Categories />
        <Products />
        <DeliveryInfo />
        <Reviews />
        <SizeGuide />
        <Contact />
        <Footer />
      </main>
    </ToastProvider>
  )
}
