"use client"

import { useSyncExternalStore } from "react"
import { getCart, getCartCount, getCartTotal, subscribe } from "@/lib/cart-store"

export function useCart() {
  const cart = useSyncExternalStore(subscribe, getCart, getCart)
  const count = useSyncExternalStore(subscribe, getCartCount, getCartCount)
  const total = useSyncExternalStore(subscribe, getCartTotal, getCartTotal)
  return { cart, count, total }
}
